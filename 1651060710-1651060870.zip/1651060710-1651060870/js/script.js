$(document).ready(function () {
    
    $.ajax({
        type: "GET",
        url: "../php/laydanhsach.php",
        data: '',
        dataType: "text",
        success: function (response) {
            var data = JSON.parse(response);
            console.log(data);
            var s='';
            s+= '<tr>';

            s+= '<th>';
            s+='STT';
            s+= '</th>';

            s+= '<th>';
            s+='Ma sinh vien';
            s+= '</th>';

            s+= '<th>';
            s+='Ho ten';
            s+= '</th>';

            s+= '<th>';
            s+='lop';
            s+= '</th>';        

            s+= '<th>';
            s+='Diemdanh';
            s+= '</th>';

            s+='</tr>';

            $.each(data, function (i, e) {
                s += "<tr>";
                s += "<td>";
                s += i+1;
                s+= "</td>";

                s += "<td>";
                s += e.msv;
                s+= "</td>";

                s += "<td>";
                s += e.ho_ten;
                s += "</td>";

                s += "<td>";
                s += e.lop;
                s += "</td>";

                s += "<td>";
                s += `<input type='checkbox' id=${e.msv} class='checkDiemDanh'>`;
                s += "</td>";
                s += "</tr>";
            });

            $('#diemdanh').html(s);
            $('#btndiemdanh').click(function () { 
                
                    var data=[];
                    $('.checkDiemDanh').each( function (index) { 
                         var check = $(this).prop('checked');
                         check = Number(check);
                         var msv = $(this).attr('id')
                         data.push({msv:msv, check:check});
                    });
    
                    $.ajax({
                        type: "POST",
                        url: "../php/danhsach.php",
                        data: {data :JSON.stringify(data)},
                        dataType: "Text",
                        success: function (response) {
                            console.log(response);
                            alert('diem danh thanh cong')
                        }
                    });
                });
                
            
        }})
});