<?php 
    $localhost = "localhost";
    $username = "root";
    $password = "";
    $database = "dbcntt";

    $conn = mysqli_connect($localhost, $username, $password, $database);

    if($conn->connect_error){
        die("Connection failed: ".$conn->connect_error);
    }
        echo "Kết nối cơ sở dữ liệu thành công";
        
        $txtID = $_POST['txtID'];
        
        $sql = "DELETE FROM tintuc WHERE idtt = '$txtID'";
        if (mysqli_query($conn, $sql)) {
            echo "Xoa thanh cong";
        } 
        else {
            echo "Xoa that bai";
        }
        mysqli_close($conn);
    ?>