<?php 
    $localhost = "localhost";
    $username = "root";
    $password = "";
    $database = "dbcntt";

    $conn = mysqli_connect($localhost, $username, $password, $database);

    if($conn->connect_error){
        die("Connection failed: ".$conn->connect_error);
    }
        echo "Kết nối cơ sở dữ liệu thành công";

  $tieude = $_POST['tieude'];
  $noidung = $_POST['noidung'];

    $sql = "INSERT INTO tintuc (tieudett, noidungtt)
            VALUES ('$tieude', '$noidung')";
    if (mysqli_query($conn, $sql)) {
        echo "Them thanh cong";
    } 
    else {
        echo "Them that bai";
    }
    mysqli_close($conn);
?>