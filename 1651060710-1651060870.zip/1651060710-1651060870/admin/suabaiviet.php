<?php
$localhost = "localhost";
$username = "root";
$password = "";
$database = "dbcntt";

$conn = mysqli_connect($localhost, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Kết nối cơ sở dữ liệu thành công";
$id = $_POST['txtID'];
$tieude = $_POST['txtTieuDe'];
$noidung = $_POST['txtNoiDung'];

$sql = "UPDATE tintuc SET noidungtt = '$noidung' WHERE idtt='$id'";
if (mysqli_query($conn, $sql)) {
    echo "Sua thanh cong";
} else {
    echo "Sua that bai";
}
