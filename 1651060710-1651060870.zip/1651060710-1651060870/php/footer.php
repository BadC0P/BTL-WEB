<footer>
        <div class="container-fuild">
            <div class="footer-top">
                <div class="container">
                    <div style="padding: 20px">
                        <h4 style="color: white; ">&copy;2019-TRƯỜNG ĐẠI HỌC THỦY LỢI</h4>
                    </div>
                    <div class="col-xl-2" style="left:500px ; padding:15px" align="center">
                        <a href="https://www.facebook.com/cse.tlu.edu.vn/" target="_blank"><button style=" border-style: none; background-color :#1b44ac"> <i class='fab fa-facebook-square' style='font-size:35px;color :white'></i></button></i></a>
                        <a href="https://www.google.com/search?hl=vi&source=hp&ei=sTtMXfKvHNnm-Aarp43wCQ&q=khoa+c%C3%B4ng+ngh%E1%BB%87+th%C3%B4ng+tin+%C4%91%E1%BA%A1i+h%E1%BB%8Dc+th%E1%BB%A7y+l%E1%BB%A3i&oq=khoa&gs_l=psy-ab.3.0.35i39l2j0l2j0i131j0l3j0i131l2.9288.14352..15173...7.0..1.111.648.8j1......0....1..gws-wiz.....10..0i67.zOVWuBcY-4k"
                            target="_blank"><button style=" border-style: none; background-color :#1b44ac"> <i class='fab fa-google-plus-square' style='font-size:35px;color : white'></i></button></i></a>
                        <a href="https://www.facebook.com/cse.tlu.edu.vn/" target="_blank"><button style=" border-style: none; background-color :#1b44ac"> <i class='fab fa-instagram' style='font-size:35px ;color :White'></i></button></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fuild" id="footer">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3">
                        <ul type="square">
                            <li>Giới Thiệu</li>
                            <li>Logo của Khoa CNTT</li>
                            <li>Lời chào mừng</li>
                            <li>Tổ Chức</li>
                            <li>Hợp tác liên kết</li>
                        </ul>
                    </div>
                    <div class="col-xl-3">
                        <ul type="square">
                            <li>Giới Thiệu</li>
                            <li>Logo của Khoa CNTT</li>
                            <li>Lời chào mừng</li>
                            <li>Tổ Chức</li>
                            <li>Hợp tác liên kết</li>
                        </ul>
                    </div>
                    <div class="col-xl-3">
                        <ul type="square">
                            <li>Giới Thiệu</li>
                            <li>Logo của Khoa CNTT</li>
                            <li>Lời chào mừng</li>
                            <li>Tổ Chức</li>
                            <li>Hợp tác liên kết</li>
                        </ul>
                    </div>
                    <div class="col-xl-3">
                        <ul type="square">
                            <li>Giới Thiệu</li>
                            <li>Logo của Khoa CNTT</li>
                            <li>Lời chào mừng</li>
                            <li>Tổ Chức</li>
                            <li>Hợp tác liên kết</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-xl-4">
                        <img src="img/LOGOFOOTER.jpg" alt="">
                    </div>
                    <div class="col-xl-8">
                        <p>&copy;2017 Khoa Công Nghệ Thông Tin - Đại Học Thủy Lợi <br>Địa chỉ: nhà C1, Đại học Thủy lợi, 175 Tây Sơn, Đống Đa, Hà Nội.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>