<?php
    include("header.php")
?>
    <section class="imgslide">
        <div class="container">
            <div id="demo" class="carousel slide" data-ride="carousel">

                <!-- Indicators -->
                <ul class="carousel-indicators">
                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                    <li data-target="#demo" data-slide-to="1"></li>
                    <li data-target="#demo" data-slide-to="2"></li>
                    <li data-target="#demo" data-slide-to="3"></li>
                    <li data-target="#demo" data-slide-to="4"></li>
                    <li data-target="#demo" data-slide-to="5"></li>
                    <li data-target="#demo" data-slide-to="6"></li>
                    <li data-target="#demo" data-slide-to="7"></li>
                    <li data-target="#demo" data-slide-to="8"></li>
                </ul>


                <div class="carousel-inner" style="margin:10px 50px 10px 50px">
                    <div class="carousel-item active">
                        <img src="../img/imgshow1.jpg" alt="Los Angeles" width="1000" height="400">
                    </div>
                    <div class="carousel-item">
                        <img src="../img/imgshow4.jpg" alt="Chicago" width="1000" height="400">
                    </div>
                    <div class="carousel-item">
                        <img src="../img/imgshow5.jpg" alt="New York" width="1000" height="400">
                    </div>
                    <div class="carousel-item">
                        <img src="http://cse.tlu.edu.vn/Portals/0/Banners/cntt-fsoft-ky.jpg" alt="New York" width="1000" height="400">
                    </div>
                    <div class="carousel-item">
                        <img src="http://cse.tlu.edu.vn/Portals/0/Banner/k54-tot-nghiep.jpg" alt="New York" width="1000" height="400">
                    </div>
                    <div class="carousel-item">
                        <img src="http://cse.tlu.edu.vn/Portals/0/Banner/sanh-t54.jpg" alt="New York" width="1000" height="400">
                    </div>
                    <div class="carousel-item">
                        <img src="http://cse.tlu.edu.vn/Portals/0/Banner/bia7-1-.jpg" alt="New York" width="1000" height="400">
                    </div>
                    <div class="carousel-item">
                        <img src="http://cse.tlu.edu.vn/Portals/0/Banner/banner.jpg" alt="New York" width="1000" height="400">
                    </div>
                </div>


                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#demo" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
            </div>
        </div>
    </section>
    <section class="Nghiencuukhoahoc">
        <div class="container">
            <h4> NGHIÊN CỨU KHOA HỌC</h4>
            <div class="row">
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <section class="Nghiencuukhoahoc">
        <div class="container">
            <h4> NGHIÊN CỨU KHOA HỌC</h4>
            <div class="row">
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <section class="Nghiencuukhoahoc">
        <div class="container">
            <h4> NGHIÊN CỨU KHOA HỌC</h4>
            <div class="row">
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
                <div class="col-xl-3">
                    <a href="">
                        <img src="../img/nghiencuu1.jpg" alt="" id="anh1">
                        <h6>Sinh viên với phong trào nghiên cứu ...</h6>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <?php
        include("footer.php")
    ?>