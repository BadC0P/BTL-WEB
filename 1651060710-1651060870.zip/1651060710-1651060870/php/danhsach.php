<?php
include 'connectdatabase.php';
$json=array();
$data = json_decode($_POST['data']);

foreach($data as $sv){
    $sql = "insert into diemdanh values($sv->msv, 'mh1', now(), $sv->check)";
    mysqli_query($conn, $sql);
}

echo json_encode($json);
mysqli_close($conn);
?>