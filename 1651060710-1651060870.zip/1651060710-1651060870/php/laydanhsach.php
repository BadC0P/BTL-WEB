<?php
include 'connectdatabase.php';
$json=array();
$sql = "select ho_ten, lop, msv from users,danhsachsv where users.id=danhsachsv.MaSV and danhsachsv.MaMH='mh1'";
$ret = mysqli_query($conn, $sql);
if(mysqli_num_rows($ret) > 0){
    // $row = mysqli_fetch_assoc($ret);
    while($row = mysqli_fetch_assoc($ret)) {
        $hoten = $row['ho_ten'];
        $lop = $row['lop'];
        $msv = $row['msv'];
        array_push($json,array("ho_ten"=>$hoten, "lop"=>$lop, 'msv'=>$msv));
    }
}
echo json_encode($json);
mysqli_close($conn);
?>